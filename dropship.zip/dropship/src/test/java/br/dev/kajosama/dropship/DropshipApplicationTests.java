package br.dev.kajosama.dropship;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DropshipApplicationTests {

	@Test
	void contextLoads() {
	}

}
